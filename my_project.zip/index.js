const express = require('express');
const app = express();
const { Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder, ButtonStyle, ApplicationCommandOptionType, PermissionsBitField } = require('discord.js');
const Discord = require('discord.js');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildEmojisAndStickers,
        GatewayIntentBits.GuildIntegrations,
        GatewayIntentBits.GuildWebhooks,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildMessageTyping,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.DirectMessageReactions,
        GatewayIntentBits.DirectMessageTyping
    ],
    partials: [
        'Message',
        'Channel',
        'GuildMember',
        'Reaction',
        'User'
    ],
});






client.once('ready', () => {
    console.log(`${client.user.tag} is ready!`);

    // تغيير حالة البوت إلى "Idle"
    client.user.setPresence({
        status: 'idle', // الحالة: online, idle, dnd, invisible
        activities: [
            {
                name: '+help', // نص الحالة
                type: 'WATCHING' // نوع النشاط: PLAYING, STREAMING, LISTENING, WATCHING
            }
        ]
    });

    
});




 

const prefix = '+';


const allowedServers = new Map(); // لتخزين الإذن لكل سيرفر
const serverLanguages = new Map(); // لتخزين اللغة لكل سيرفر

// اسم الملف الذي سيتم حفظ أسماء السيرفرات فيه
const SERVERS_FILE = 'servers.json'; // ملف JSON

// دالة لقراءة الملف
function readServersFile() {
    if (!fs.existsSync(SERVERS_FILE)) {
        fs.writeFileSync(SERVERS_FILE, '[]'); // إنشاء ملف فارغ إذا لم يكن موجودًا
        return [];
    }
    const data = fs.readFileSync(SERVERS_FILE, 'utf8');
    return JSON.parse(data); // إرجاع قائمة بأسماء السيرفرات
}

// دالة لكتابة الملف
function writeServersFile(servers) {
    fs.writeFileSync(SERVERS_FILE, JSON.stringify(servers, null, 2)); // حفظ أسماء السيرفرات في الملف
}

// عند انضمام البوت إلى سيرفر جديد
client.on('guildCreate', guild => {
    allowedServers.set(guild.id, true); // منح الإذن تلقائيًا
    serverLanguages.set(guild.id, 'english'); // تعيين اللغة الافتراضية

    // إضافة اسم السيرفر إلى الملف
    const servers = readServersFile();
    if (!servers.includes(guild.name)) {
        servers.push(guild.name); // إضافة اسم السيرفر الجديد
        writeServersFile(servers); // حفظ التغييرات في الملف
        console.log(`Added server: ${guild.name}`); // إظهار رسالة في الكونسول (اختياري)
    }
});

// عند مغادرة البوت سيرفر
client.on('guildDelete', guild => {
    allowedServers.delete(guild.id); // حذف الإذن
    serverLanguages.delete(guild.id); // حذف اللغة

    // حذف اسم السيرفر من الملف
    const servers = readServersFile();
    const updatedServers = servers.filter(name => name !== guild.name); // حذف اسم السيرفر
    writeServersFile(updatedServers); // حفظ التغييرات في الملف
    console.log(`Removed server: ${guild.name}`); // إظهار رسالة في الكونسول (اختياري)
});

// عند تفاعل المستخدم مع الأوامر
client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;

    const language = serverLanguages.get(interaction.guild.id) || 'english'; // اللغة الافتراضية: إنجليزية

    // الأمر /permission
    if (interaction.commandName === 'permission') {
        // التحقق من صلاحية ADMINISTRATOR
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            const embed = new EmbedBuilder()
                .setDescription(
                    language === 'english'
                        ? 'This command can only be used by users with `ADMINISTRATOR` permission!'
                        : 'يمكن استخدام هذا الأمر فقط من قبل المستخدمين الذين لديهم صلاحية `ADMINISTRATOR`!'
                )
                .setColor('#FF0000');
            await interaction.reply({ embeds: [embed], ephemeral: true });
            return;
        }

        // إنشاء أزرار Allow و Refuse
        const buttonRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('allow')
                .setLabel(language === 'english' ? 'Allow' : 'السماح')
                .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId('refuse')
                .setLabel(language === 'english' ? 'Refuse' : 'رفض')
                .setStyle(ButtonStyle.Danger)
        );

        // إنشاء الرسالة
        const embed = new EmbedBuilder()
            .setTitle(language === 'english' ? 'Permission Settings' : 'إعدادات الإذن')
            .setDescription(
                language === 'english'
                    ? 'Do you want to allow the bot to suggest emojis from this server to other servers?'
                    : 'هل تريد السماح للبوت باقتراح الإيموجيات من هذا السيرفر إلى سيرفرات أخرى؟'
            )
            .setColor('#00FFFF');

        // إرسال الرسالة مع الأزرار
        await interaction.reply({ embeds: [embed], components: [buttonRow], ephemeral: false });

        // إنشاء Collector للتعامل مع النقرات على الأزرار
        const filter = i => i.customId === 'allow' || i.customId === 'refuse';
        const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000 });

        collector.on('collect', async i => {
            await i.deferUpdate(); // تأجيل التفاعل

            if (i.customId === 'allow') {
                allowedServers.set(interaction.guild.id, true);
                const allowEmbed = new EmbedBuilder()
                    .setTitle(language === 'english' ? '✔️ Permission Granted' : '✔️ تم منح الإذن')
                    .setDescription(
                        language === 'english'
                            ? 'You have allowed the bot to suggest emojis from this server to other servers.'
                            : 'لقد سمحت للبوت باقتراح الإيموجيات من هذا السيرفر إلى سيرفرات أخرى.'
                    )
                    .setColor('#00FF00');
                await i.editReply({ embeds: [allowEmbed], components: [] }); // إزالة الأزرار
            } else if (i.customId === 'refuse') {
                allowedServers.set(interaction.guild.id, false);
                const refuseEmbed = new EmbedBuilder()
                    .setTitle(language === 'english' ? '❌ Permission Denied' : '❌ تم رفض الإذن')
                    .setDescription(
                        language === 'english'
                            ? 'You have refused to allow the bot to suggest emojis from this server to other servers.'
                            : 'لقد رفضت السماح للبوت باقتراح الإيموجيات من هذا السيرفر إلى سيرفرات أخرى.'
                    )
                    .setColor('#FF0000');
                await i.editReply({ embeds: [refuseEmbed], components: [] }); // إزالة الأزرار
            }

            collector.stop(); // إيقاف Collector بعد التفاعل
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                const timeoutEmbed = new EmbedBuilder()
                    .setTitle(language === 'english' ? '⏳ Time Out' : '⏳ انتهى الوقت')
                    .setDescription(
                        language === 'english'
                            ? 'You did not respond in time.'
                            : 'لم تقم بالرد في الوقت المحدد.'
                    )
                    .setColor('#FFFF00');
                interaction.followUp({ embeds: [timeoutEmbed], ephemeral: true });
            }
        });
    }

    // الأمر /suggestemojis
    if (interaction.commandName === 'suggestemojis') {
        // التحقق من صلاحية MANAGE_EMOJIS_AND_STICKERS
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageEmojisAndStickers)) {
            const embed = new EmbedBuilder()
                .setDescription(
                    language === 'english'
                        ? 'You do not have the required permission `Manage Emojis and Stickers`. You need this permission to use this command👀'
                        : 'ليس لديك صلاحية `إدارة الإيموجيات والملصقات`. تحتاج هذه الصلاحية حتى تستخدم الأمر👀'
                )
                .setColor('#FF0000');
            await interaction.reply({ embeds: [embed], ephemeral: true });
            return;
        }

        // جمع الإيموجيات من السيرفرات المسموح لها
        let emojis = [];
        client.guilds.cache.forEach(guild => {
            if (allowedServers.get(guild.id) === true) {
                guild.emojis.cache.forEach(emoji => {
                    if (!emojis.includes(emoji) && 
                        !interaction.guild.emojis.cache.find(e => e.name === emoji.name)) {
                        emojis.push(emoji);
                    }
                });
            }
        });

        // إذا لم توجد إيموجيات متاحة
        if (emojis.length === 0) {
            const embed = new EmbedBuilder()
                .setTitle(language === 'english' ? 'No Emojis Available❌' : 'لا توجد ايموجيات متاحة❌')
                .setDescription(
                    language === 'english'
                        ? 'No emojis are available to suggest from other servers.'
                        : 'لا توجد ايموجيات متاحة للاقتراح من سيرفرات أخرى.'
                )
                .setColor('#FF0000');
            await interaction.reply({ embeds: [embed], ephemeral: true });
            return;
        }

        // اختيار 5 إيموجيات عشوائية
        emojis = emojis.sort(() => Math.random() - 0.5).slice(0, 5);
        const embed = new EmbedBuilder()
            .setTitle(language === 'english' ? 'Suggested Emojis' : 'الإيموجيات المقترحة')
            .setDescription(
                language === 'english'
                    ? 'Here are 5 suggested emojis from other servers:\n' + emojis.map(e => e.toString()).join(' ')
                    : 'هذه 5 اقتراحات الايموجيات من سيرفرات أخرى:\n' + emojis.map(e => e.toString()).join(' ')
            )
            .setColor('#00FFFF')
            .setFooter({
                text: language === 'english'
                    ? 'React with ✅ to add them or ❌ to cancel.'
                    : 'اضغط على ✅ لإضافتها أو ❌ لإلغاء الأمر.'
            });

        const sentMessage = await interaction.reply({ embeds: [embed], fetchReply: true });

        // إضافة ردود فعل للرسالة
        await sentMessage.react('✅');
        await sentMessage.react('❌');

        // إنشاء Collector للتعامل مع ردود الفعل
        const filter = (reaction, user) => {
            return ['✅', '❌'].includes(reaction.emoji.name) && user.id === interaction.user.id;
        };

        sentMessage.awaitReactions({ filter, max: 1, time: 60000, errors: ['time'] })
            .then(collected => {
                const reaction = collected.first();
                if (reaction.emoji.name === '✅') {
                    emojis.forEach(emoji => {
                        if (!interaction.guild.emojis.cache.find(e => e.name === emoji.name)) {
                            interaction.guild.emojis.create({ attachment: emoji.url, name: emoji.name });
                        }
                    });
                    interaction.followUp(
                        language === 'english'
                            ? 'The suggested emojis have been added successfully✅'
                            : 'تمت إضافة الايموجيات المقترحة بنجاح✅'
                    );
                } else {
                    interaction.followUp(
                        language === 'english'
                            ? 'The suggested emojis were not added❎'
                            : 'لم يتم إضافة الايموجيات المقترحة❎'
                    );
                }
            })
            .catch(() => {
                interaction.followUp(
                    language === 'english'
                        ? 'You did not respond in time⏳.'
                        : 'لم تقم بالرد في الوقت المحدد⏳.'
                );
            });
    }
});

// تسجيل الأوامر
client.on('ready', async () => {
    console.log(`Logged in as ${client.user.tag}!`);

    const commands = await client.application.commands.set([
        {
            name: 'permission',
            description: 'Set permissions for the bot to suggest emojis.',
        },
        {
            name: 'suggestemojis',
            description: 'Suggest emojis from other servers.',
        },
    ]);
    
});










client.on('messageCreate', message => {
  if (!message.guild) return;
  language = serverLanguages.get(message.guild.id) || 'english';
});

app.get('/', (req, res) => {
  res.send('EMOJI');
});

client.on('ready', async () => {
  

  const addEmojiCommand = {
    name: 'addemoji',
    description: 'Add an emoji to the server',
    options: [
      {
        name: 'emoji',
        type: ApplicationCommandOptionType.String,
        description: 'The emoji to add',
        required: true
      },
      {
        name: 'name',
        type: ApplicationCommandOptionType.String,
        description: 'The name for the emoji',
        required: false
      }
    ]
  };

  await client.application.commands.create(addEmojiCommand);

  client.user.setActivity('+help');
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return;
  if (interaction.commandName === 'addemoji') {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageEmojisAndStickers)) {
      const language = serverLanguages.get(interaction.guild.id) || 'english';
      const embed = new EmbedBuilder()
        .setDescription(language === 'english' ? `You do not have the required permission \`ManageEmojisAndStickers\`. You need this permission to use this command👀` : `ليس لديك صلاحية \`ManageEmojisAndStickers\` تحتاج هذه الصلاحية حتى تستخدم الامر👀`)
        .setColor("#FF0000");
      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }
    const emoji = interaction.options.getString('emoji');
    const name = interaction.options.getString('name');
    let info = parseEmoji(emoji);
    if (!info.id) {
      const embed = new EmbedBuilder()
        .setTitle(language === 'english' ? `Add Emoji` : `إضافة ايموجي`)
        .setDescription(language === 'english' ? `**I can't find an emoji to add🤔**` : `**لا يمكنني العثور على ايموجي لإضافته🤔**`)
        .setColor("#00FFFF");
      await interaction.reply({ embeds: [embed] });
      return;
    }
    if (interaction.guild.emojis.cache.find(e => e.name === info.name)) {
      const embed = new EmbedBuilder()
        .setTitle(language === 'english' ? `Add Emoji` : `إضافة ايموجي`)
        .setDescription(language === 'english' ? `The emoji ${emoji} is already added to the server❎` : `الايموجي ${emoji} مضاف بالفعل إلى السيرفر❎`)
        .setColor("#FF0000");
      await interaction.reply({ embeds: [embed] });
      return;
    }
    let type = info.animated ? '.gif' : '.png';
    let url = `https://cdn.discordapp.com/emojis/${info.id + type}`;
    var emj = await interaction.guild.emojis.create({ attachment: url, name: name || info.name, reason: `emoji created by ${client.user.tag}` });
    const embed = new EmbedBuilder()
      .setTitle(language === 'english' ? `Add Emoji` : `إضافة ايموجي`)
      .setDescription(language === 'english' ? `**Emoji has been added successfully✅ ${emj}**` : `**تمت إضافة الايموجي بنجاح ${emj}✅**`)
      .setColor("#00FFFF");
    await interaction.reply({ embeds: [embed] });
  }
});



client.on('messageCreate', senko => {
  if (senko.content.startsWith(prefix + 'help')) {
    senko.channel.send(language === 'english' ? '**Check your DM**' : '**شوف خاصك**').then(messages => {
      // حذف الرسالة بعد 5 ثوانٍ
      setTimeout(() => messages.delete(), 5000);

      const embed = new EmbedBuilder()
        .setDescription(
          language === 'english'
            ? `**Welcome, this is my help menu **
⌄ـــــــــــــــــــــــــــProEmojiـــــــــــــــــــــــــــــ⌄

The prefix of the bot is **[ + ]**

⌄ـــــــــــــــــــــــــــProEmojiـــــــــــــــــــــــــــــ⌄

If you do not have Nitro you can write this command **+suggestemojis** so that the bot will suggest emojis to you from different servers that the bot has

⌄ـــــــــــــــــــــــــــProEmojiـــــــــــــــــــــــــــــ⌄

You can use this slash command  
**/image_to_emoji** to convert the image into an emoji and save it on your server

⌄ـــــــــــــــــــــــــــProEmojiـــــــــــــــــــــــــــــ⌄

You can add an emoji using this command **+addemoji** and you will be able to add an emoji but with the original name of the emoji

⌄ـــــــــــــــــــــــــــProEmojiـــــــــــــــــــــــــــــ⌄

You can add an emoji but change the name of the emoji using this Slash Command 
**/addemoji** 

⌄ـــــــــــــــــــــــــــProEmojiـــــــــــــــــــــــــــــ⌄

If you want to rename of the emoji you can use this slash command **/rename_emoji** and the name of the emoji will be renamed

⌄ـــــــــــــــــــــــــــProEmojiـــــــــــــــــــــــــــــ⌄

You can change the bot's language using this Slash Command command **/language**

⌄ـــــــــــــــــــــــــــProEmojiـــــــــــــــــــــــــــــ⌄

**I hope you like the bot and enjoy using it 😉**

`
            : `** مرحبًا، هذه هي قائمة المساعدة الخاصة بي **
⌄ـــــــــــــــــــــــــــProEmojiـــــــــــــــــــــــــــــ⌄

  بادئة البوت هي **[ + ]** 
  
⌄ـــــــــــــــــــــــــــProEmojiـــــــــــــــــــــــــــــ⌄

 اذا كنت لا تملك نيترو تستطيع كتابة هذا الامر حتى يقترح لك البوت ايموجيات من سيرفرات مختلفة داخلها البوت **suggestemojis+**

⌄ـــــــــــــــــــــــــــProEmojiـــــــــــــــــــــــــــــ⌄

 يمكنك استخدام امر سلاش كوماند **image_to_emoji/** حتى يتم تحويل الصوره الى ايموجي و يحفظها في سيرفرك 

⌄ـــــــــــــــــــــــــــProEmojiـــــــــــــــــــــــــــــ⌄

 يمكنك اضافة ايموجي باستخدام هذا الامر **addemoji+** و سوف تستطيع اضافة ايموجي ولكن مع اسم الايموجي الاصلي

⌄ـــــــــــــــــــــــــــProEmojiـــــــــــــــــــــــــــــ⌄

 يمكنك اضافة ايموجي ولكن مع تغيير الاسم بأستخدام سلاش كوماند **addemoji/** 

⌄ـــــــــــــــــــــــــــProEmojiـــــــــــــــــــــــــــــ⌄

اذا كنت تريد تغيير اسم الايموجي يمكنك استخدام امر السلاش كوماند هذا **rename_emoji/** و سوف يتم تغيير اسم الايموجي 

⌄ـــــــــــــــــــــــــــProEmojiـــــــــــــــــــــــــــــ⌄

تستطيع تغيير لغة البوت باستخدام هذا السلاش كوماند **language/** 

⌄ـــــــــــــــــــــــــــProEmojiـــــــــــــــــــــــــــــ⌄

**اتمنى ان يعجبك البوت و تستمتع باستخدامه😉**
`
        )
        .setFooter({ text: `ProEmoji` })
        .setColor(`#00FFFF`)
        .setTimestamp();

      senko.author.send({ embeds: [embed] }).catch(error => senko.reply(language === 'english' ? '**Please open your DM**' : '**رجاء فتح خاصك**'));
    });
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "addemoji")) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageEmojisAndStickers)) {
      const language = serverLanguages.get(message.guild.id) || 'english';
      const embed = new EmbedBuilder()
        .setDescription(language === 'english' ? `You do not have the required permission \`ManageEmojisAndStickers\`. You need this permission to use this command👀` : `ليس لديك صلاحية \`ManageEmojisAndStickers\` تحتاج هذه الصلاحية حتى تستخدم الامر👀`)
        .setColor("#FF0000");
      message.channel.send({ embeds: [embed] }).then(msg => {
        setTimeout(() => msg.delete(), 5000);
      });
      return;
    }
    let args = message.content.split(" ").slice(1);
    const emojis = args;
    if (!emojis.length) {
      const embed = new EmbedBuilder()
        .setTitle(language === 'english' ? `Add Emoji` : `إضافة ايموجي`)
        .setDescription(language === 'english' ? `**Please choose the emoji you want to add🤔**` : `**يرجى اختيار الايموجي الذي تريد إضافته🤔**`)
        .setColor("#00FFFF");
      message.channel.send({ embeds: [embed] });
      return;
    }
    let names = [];
    for (let i = 0; i < emojis.length; i++) {
      const emoji = emojis[i];
      let info = parseEmoji(emoji);
      if (!info.id) {
        continue;
      }
      if (message.guild.emojis.cache.find(e => e.name === info.name && e.id === info.id)) {
        const embed = new EmbedBuilder()
          .setTitle(language === 'english' ? `Add Emoji` : `إضافة ايموجي`)
          .setDescription(language === 'english' ? `The emoji ${emojis[i]} is already added to the server` : `الايموجي ${emojis[i]} مضاف بالفعل إلى السيرفر`)
          .setColor("#FF0000");
        message.channel.send({ embeds: [embed] });
        continue;
      }
      let type = info.animated ? ".gif" : ".png";
      let url = `https://cdn.discordapp.com/emojis/${info.id + type}`;
      var emj = await message.guild.emojis.create({ attachment: url, name: info.name, reason: `emoji created by ${client.user.tag}` });
      names.push(emj);
      if (i === emojis.length - 1 && !names.length) {
        const embed = new EmbedBuilder()
          .setTitle(language === 'english' ? `Add Emoji` : `إضافة ايموجي`)
          .setDescription(language === 'english' ? "**I can't find an emoji to add🤔**" : "**لا يمكنني العثور على ايموجي لإضافته🤔**")
          .setColor("#00FFFF");
        message.channel.send({ embeds: [embed] });
        return;
      }
    }
    if (names.length) {
      const embed = new EmbedBuilder()
        .setTitle(language === 'english' ? `Add Emoji` : `إضافة ايموجي`)
        .setDescription(language === 'english' ? `**Emoji has been added successfully✅ ${names.join("/")}**` : `**تمت إضافة الايموجي بنجاح ${names.join("/")}✅**`)
        .setColor("#00FFFF");
      message.channel.send({ embeds: [embed] });
    }
  }
});




const isImageUrl = require('is-image-url');

const words = {
  emoji: 'image_to_emoji',
  added: {
    ar: 'تمت إضافته بنجاح',
    en: 'added successfully'
  },
  error: {
    ar: 'عذرا، حدث خطأ',
    en: 'Sorry, something went wrong'
  },
  invalid_url: {
    ar: 'عذرًا، يجب إدخال رابط صحيح لصورة في خيار **"url"**',
    en: 'Sorry, you must enter a valid image URL in the **"url"** option'
  },
  none: 'There are no emojis in this server'
};

const usedUrls = {};

client.on('ready', async () => {
  
  const commands = await client.application.commands.fetch();
  const emojiCommand = commands.find(command => command.name === words.emoji);
  if (emojiCommand) {
    await emojiCommand.delete();
  }
  await client.application.commands.create({
    name: words.emoji,
    description: `Convert the image to emoji`,
    options: [
      {
        name: 'name',
        description: `The name of the ${words.emoji}`,
        type: ApplicationCommandOptionType.String,
        required: true
      },
      {
        name: 'url',
        description: `The URL of the image`,
        type: ApplicationCommandOptionType.String,
        required: true
      }
    ]
  });
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return;

  const commandName = interaction.commandName;
  const nameOption = interaction.options.getString('name');
  const urlOption = interaction.options.getString('url');

  if (commandName === words.emoji) {
    const language = serverLanguages.get(interaction.guild.id) || 'english';
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageEmojisAndStickers)) {
      const embed = new EmbedBuilder()
        .setDescription(language === 'english' ? `You do not have the required permission \`ManageEmojisAndStickers\`. You need this permission to use this command👀` : `ليس لديك صلاحية \`ManageEmojisAndStickers\` تحتاج هذه الصلاحية حتى تستخدم الامر👀`)
        .setColor("#FF0000");
      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }
    if (nameOption && urlOption) {
      if (!isImageUrl(urlOption)) {
        await interaction.reply(language === "english" ? words.invalid_url.en : words.invalid_url.ar);
      } else {
        try {
          if (usedUrls[urlOption] && usedUrls[urlOption].includes(interaction.guild.id)) {
            await interaction.reply(language === "english" ? `This image has already been used as an emoji in this server.` : `تم استخدام هذه الصورة بالفعل كـ ايموجي في هذا االسيرفر`);
          } else {
            const emoji = await interaction.guild.emojis.create({ attachment: urlOption, name: nameOption });
            usedUrls[urlOption] = usedUrls[urlOption] || [];
            usedUrls[urlOption].push(interaction.guild.id);
            await interaction.reply(language === "english" ? words.added.en : words.added.ar);
          }
        } catch (error) {
          await interaction.reply(`${language === "english" ? words.error.en : words.error.ar}. ${error.message}`);
        }
      }
    } else {
      await interaction.reply(language === "english" ? `Please provide both a name and a URL for the emoji you want to add.` : `يرجى تقديم كل من اسم و رابط للايموجي الذي ترغب في إضافته.`);
    }
  }
});



        


client.on('ready', async () => {
  
  const commands = await client.application.commands.fetch();
  const listEmojisCommand = commands.find(command => command.name === 'list_emojis');
  if (!listEmojisCommand) {
    await client.application.commands.create({
      name: 'list_emojis',
      description: `List all emojis in the server`,
    });
  }
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return;

  if (interaction.commandName === 'list_emojis') {
    const emojis = Array.from(interaction.guild.emojis.cache.values());
    if (emojis.length === 0) {
      await interaction.reply({ content: 'There are no emojis in this server', ephemeral: true });
    } else {
      let pages = [];
      let i, j, temparray, chunk = 50;
      for (i = 0, j = emojis.length; i < j; i += chunk) {
        temparray = emojis.slice(i, i + chunk);
        pages.push(temparray.map(emoji => emoji.toString()).join(' '));
      }

      let page = 1;
      const embed = new EmbedBuilder()
        .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL() })
        .setTitle('Emojis')
        .setColor('#00FFFF')
        .setDescription(pages[page - 1] || 'No emojis to display')
        .setFooter({ text: `${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() });

      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('previous')
            .setLabel('Previous')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('next')
            .setLabel('Next')
            .setStyle(ButtonStyle.Secondary),
        );

      await interaction.deferReply({ ephemeral: true });
      await interaction.editReply({ embeds: [embed], components: [row] });

      const filter = i => i.customId === 'next' || i.customId === 'previous';
      const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000 });

      collector.on('collect', async i => {
        if (i.customId === 'next') {
          page++;
          if (page > pages.length) page = 1;
        } else if (i.customId === 'previous') {
          page--;
          if (page < 1) page = pages.length;
        }

        const embed = new EmbedBuilder()
          .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL() })
          .setTitle('Emojis')
          .setColor('#00FFFF')
          .setDescription(pages[page - 1])
          .setFooter({ text: `${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() });

        await i.update({ embeds: [embed] });
      });
    }
  }
});



client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return;

  if (interaction.commandName === 'language') {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      const embed = new EmbedBuilder()
        .setDescription(language === 'english' ? `You do not have the required permission \`Administrator\`. You need this permission to use this command👀` : `ليس لديك صلاحية \`Administrator\` تحتاج هذه الصلاحية حتى تستخدم الامر👀`)
        .setColor("#FF0000");
      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }

    const embed = new EmbedBuilder()
      .setTitle('اختار اللغة-Choose the language ')
      .setColor('#00FFFF')
      .setDescription('اختار اللغة التي تريد استخدامها------Choose the language you want to use ')
      .addFields(
        { name: 'عربي', value: 'اضغط على 🇦 للاختيار', inline: true },
        { name: 'English', value: 'Click on 🇺🇸 to select', inline: true }
      );

    await interaction.reply({ embeds: [embed] }).then(async () => {
      const sentMessage = await interaction.fetchReply();
      await sentMessage.react('🇦');
      await sentMessage.react('🇺🇸');

      const filter = (reaction, user) => {
        return ['🇦', '🇺🇸'].includes(reaction.emoji.name) && user.id === interaction.user.id;
      };

      sentMessage.awaitReactions({ filter, max: 1, time: 60000, errors: ['time'] })
        .then(collected => {
          const reaction = collected.first();
          if (reaction.emoji.name === '🇦') {
            serverLanguages.set(interaction.guild.id, 'arabic');
            interaction.followUp('لقد اخترت اللغة العربية');
          } else {
            serverLanguages.set(interaction.guild.id, 'english');
            interaction.followUp('You have chosen English');
          }
        })
        .catch(() => {
          const language = serverLanguages.get(interaction.guild.id) || 'english';
          interaction.followUp(language === 'english' ? 'You did not choose a language in the allotted time' : 'لم تقم باختيار اللغة في الوقت المحدد');
        });
    });
  }
});







client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;

    const language = interaction.guild.id ? 'english' : 'arabic'; // يمكن تخصيص اللغة إذا لزم الأمر

    if (interaction.commandName === 'delete_emoji') {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageEmojisAndStickers)) {
            const embed = new EmbedBuilder()
                .setTitle(language === 'english' ? `Delete Emoji` : `حذف ايموجي`)
                .setDescription(
                    language === 'english'
                        ? `You do not have the required permission \`ManageEmojisAndStickers\`. You need this permission to use this command👀`
                        : `ليس لديك صلاحية \`ManageEmojisAndStickers\` تحتاج هذه الصلاحية حتى تستخدم الامر👀`
                )
                .setColor("#FF0000");
            await interaction.reply({ embeds: [embed], ephemeral: true });
            return;
        }

        const emojiInput = interaction.options.getString('emoji');
        const emojiRegex = /<(a)?:\w+:(\d+)>/; // التعرف على الإيموجي المخصص
        const match = emojiInput.match(emojiRegex);

        if (!match) {
            const embed = new EmbedBuilder()
                .setTitle(language === 'english' ? `Delete Emoji` : `حذف ايموجي`)
                .setDescription(
                    language === 'english'
                        ? `**I can't find an emoji to delete🤔**`
                        : `**لا يمكنني العثور على ايموجي لحذفه🤔**`
                )
                .setColor("#00FFFF");
            await interaction.reply({ embeds: [embed], ephemeral: true });
            return;
        }

        const emojiId = match[2]; // استخراج معرف الإيموجي
        const emojiAnimated = match[1] ? 'a' : ''; // التحقق إذا كان الإيموجي متحركًا
        const emj = interaction.guild.emojis.cache.get(emojiId);

        if (!emj) {
            const embed = new EmbedBuilder()
                .setTitle(language === 'english' ? `Delete Emoji` : `حذف ايموجي`)
                .setDescription(
                    language === 'english'
                        ? `The emoji ${emojiInput} is not found in the server❎`
                        : `الايموجي ${emojiInput} غير موجود في السيرفر❎`
                )
                .setColor("#FF0000");
            await interaction.reply({ embeds: [embed], ephemeral: true });
            return;
        }

        // حذف الإيموجي
        await emj.delete();

        // صيغة الإيموجي لعرضه في الرسالة
        const emojiDisplay = `<${emojiAnimated}:${emj.name}:${emojiId}>`;

        // عرض الإيموجي نفسه في رسالة النجاح
        const embed = new EmbedBuilder()
            .setTitle(language === 'english' ? `Delete Emoji` : `حذف ايموجي`)
            .setDescription(
                language === 'english'
                    ? `**Emoji "${emojiDisplay}" has been deleted successfully✅**`
                    : `**تم حذف الايموجي "${emojiDisplay}" بنجاح✅**`
            )
            .setColor("#00FFFF");
        await interaction.reply({ embeds: [embed] });
    }
});

let suggestedEmojis = [];

client.on('messageCreate', message => {
  if (message.content === prefix + 'suggestemojis') {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageEmojisAndStickers)) {
      const language = serverLanguages.get(message.guild.id) || 'english';
      const embed = new EmbedBuilder()
        .setDescription(language === 'english' ? `You do not have the required permission \`ManageEmojisAndStickers\`. You need this permission to use this command👀` : `ليس لديك صلاحية \`ManageEmojisAndStickers\` تحتاج هذه الصلاحية حتى تستخدم الامر👀`)
        .setColor("#FF0000");
      message.channel.send({ embeds: [embed] }).then(msg => {
        setTimeout(() => msg.delete(), 5000);
      });
      return;
    }
    let emojis = [];
    client.guilds.cache.forEach(guild => {
      guild.emojis.cache.forEach(emoji => {
        if (!emojis.includes(emoji) && !message.guild.emojis.cache.find(e => e.name === emoji.name)) {
          emojis.push(emoji);
        }
      });
    });
    emojis = emojis.sort(() => Math.random() - 0.5).slice(0, 5);
    suggestedEmojis = emojis;
    const language = serverLanguages.get(message.guild.id) || 'english';
    let reply = language === 'english' ? 'Here are 5 suggested emojis from different servers: ' : 'هذه 5 اقتراحات الايموجيات من سيرفرات مختلفة: ';
    emojis.forEach(emoji => {
      reply += `${emoji} `;
    });
    reply += language === 'english' ? '\nDo you want to add these emojis?' : '\nهل ترغب في إضافة هذه الايموجيات؟';
    message.channel.send(reply);
  } else if (message.content === 'نعم' || message.content.toLowerCase() === 'yes') {
    if (suggestedEmojis.length > 0) {
      suggestedEmojis.forEach(emoji => {
        if (!message.guild.emojis.cache.find(e => e.name === emoji.name)) {
          message.guild.emojis.create(emoji.url, emoji.name);
        }
      });
      const language = serverLanguages.get(message.guild.id) || 'english';
      message.channel.send(language === 'english' ? 'The suggested emojis have been added successfully✅' : 'تمت إضافة الايموجيات المقترحة بنجاح✅');
      suggestedEmojis = [];
    }
  } else if (message.content === 'لا' || message.content.toLowerCase() === 'no') {
    if (suggestedEmojis.length > 0) {
      const language = serverLanguages.get(message.guild.id) || 'english';
      message.channel.send(language === 'english' ? 'The suggested emojis were not added❎' : 'لم يتم إضافة الايموجيات المقترحة❎');
      suggestedEmojis = [];
    }
  }
});

client.on('ready', async () => {
  

  // تسجيل أمر suggestemojis
  const suggestEmojisCommand = {
    name: 'suggestemojis',
    description: 'Suggest emojis from other servers',
  };

  // تسجيل الأمر الجديد
  await client.application.commands.create(suggestEmojisCommand);

  
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return;

  if (interaction.commandName === 'suggestemojis') {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageEmojisAndStickers)) {
      const embed = new EmbedBuilder()
        .setDescription(language === 'english' ? `You do not have the required permission \`ManageEmojisAndStickers\`. You need this permission to use this command👀` : `ليس لديك صلاحية \`ManageEmojisAndStickers\` تحتاج هذه الصلاحية حتى تستخدم الامر👀`)
        .setColor("#FF0000");
      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }

    let emojis = [];
    client.guilds.cache.forEach(guild => {
      guild.emojis.cache.forEach(emoji => {
        if (!emojis.includes(emoji) && !interaction.guild.emojis.cache.find(e => e.name === emoji.name)) {
          emojis.push(emoji);
        }
      });
    });

    emojis = emojis.sort(() => Math.random() - 0.5).slice(0, 5);
    suggestedEmojis = emojis;

    const language = serverLanguages.get(interaction.guild.id) || 'english';
    let reply = language === 'english' ? 'Here are 5 suggested emojis from different servers: ' : 'هذه 5 اقتراحات الايموجيات من سيرفرات مختلفة: ';
    emojis.forEach(emoji => {
      reply += `${emoji} `;
    });
    reply += language === 'english' ? '\nDo you want to add these emojis?' : '\nهل ترغب في إضافة هذه الايموجيات؟';

    // الرد الأولي
    await interaction.reply(reply);

    // تفاعل المستخدم مع الرد
    const filter = response => {
      return (response.content.toLowerCase() === 'yes' || response.content === 'نعم' || response.content.toLowerCase() === 'no' || response.content === 'لا') && response.author.id === interaction.user.id;
    };

    try {
      const collected = await interaction.channel.awaitMessages({ filter, max: 1, time: 60000, errors: ['time'] });
      const response = collected.first();
      if (response.content.toLowerCase() === 'yes' || response.content === 'نعم') {
        suggestedEmojis.forEach(emoji => {
          if (!interaction.guild.emojis.cache.find(e => e.name === emoji.name)) {
            interaction.guild.emojis.create(emoji.url, emoji.name);
          }
        });
        await interaction.followUp(language === 'english' ? 'The suggested emojis have been added successfully✅' : 'تمت إضافة الايموجيات المقترحة بنجاح✅');
      } else {
        await interaction.followUp(language === 'english' ? 'The suggested emojis were not added❎' : 'لم يتم إضافة الايموجيات المقترحة❎');
      }
    } catch (error) {
      await interaction.followUp(language === 'english' ? 'You did not respond in time.' : 'لم تقم بالرد في الوقت المحدد.');
    }
  }
});



client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return;

  const language = interaction.guild.id ? 'english' : 'arabic';

  if (interaction.commandName === 'rename_emoji') {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageEmojisAndStickers)) {
      const embed = new EmbedBuilder()
        .setTitle(language === 'english' ? `Rename Emoji` : `تغيير اسم الايموجي`)
        .setDescription(
          language === 'english'
            ? `You do not have the required permission \`ManageEmojisAndStickers\`. You need this permission to use this command👀`
            : `ليس لديك صلاحية \`ManageEmojisAndStickers\` تحتاج هذه الصلاحية حتى تستخدم الامر👀`
        )
        .setColor("#FF0000");
      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }

    const emojiInput = interaction.options.getString('emoji');
    const newName = interaction.options.getString('name');

    // استخدم التعبير المنتظم لاستخراج الإيموجي المخصص
    const emojiRegex = /<(a)?:\w+:(\d+)>/;
    const match = emojiInput.match(emojiRegex);

    if (!match) {
      const embed = new EmbedBuilder()
        .setTitle(language === 'english' ? `Rename Emoji` : `تغيير اسم الايموجي`)
        .setDescription(
          language === 'english'
            ? `**I can't find an emoji to rename🤔**`
            : `**لا يمكنني العثور على الإيموجي لتغيير اسمه🤔**`
        )
        .setColor("#00FFFF");
      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }

    const emojiId = match[2];
    const emj = interaction.guild.emojis.cache.get(emojiId);

    if (!emj) {
      const embed = new EmbedBuilder()
        .setTitle(language === 'english' ? `Rename Emoji` : `تغيير اسم الايموجي`)
        .setDescription(
          language === 'english'
            ? `**The emoji ${emojiInput} is not found in the server❎**`
            : `**الإيموجي ${emojiInput} غير موجود في الخادم❎**`
        )
        .setColor("#FF0000");
      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }

    try {
      await emj.edit({ name: newName });
      const embed = new EmbedBuilder()
        .setTitle(language === 'english' ? `Rename Emoji` : `تغيير اسم الايموجي`)
        .setDescription(
          language === 'english'
            ? `**Emoji has been renamed successfully to ${newName} **\n${emj}✅`
            : `**تم تغيير اسم الإيموجي بنجاح إلى ${newName} **\n${emj}✅`
        )
        .setColor("#00FFFF");
      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Error renaming emoji:', error);
      const embed = new EmbedBuilder()
        .setTitle(language === 'english' ? `Rename Emoji` : `تغيير اسم الايموجي`)
        .setDescription(
          language === 'english'
            ? `**There was an error renaming the emoji. Please try again later.❎**`
            : `**حدث خطأ أثناء تغيير اسم الإيموجي. حاول مجددًا لاحقًا❎**`
        )
        .setColor("#FF0000");
      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
});

client.login('MTAwOTQyNjY3OTA2MTU1MzE2Mg.GPSJN6.HrfdifW6E6qhIA8h0i5RheO7KUDgpzIhhd5Q0o');