{pkgs}: {
  deps = [
    pkgs.zip
   ];
}
